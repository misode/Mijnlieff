package mijnlieff.client.establisher.game;

import mijnlieff.client.game.Player;

public interface GameEstablishedListener {

    void establishedGame(Player opponent);
}
