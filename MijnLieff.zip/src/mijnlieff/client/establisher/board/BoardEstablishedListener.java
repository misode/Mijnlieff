package mijnlieff.client.establisher.board;

import mijnlieff.client.board.BoardSetting;

public interface BoardEstablishedListener {

    void establishedBoard(BoardSetting boardSetting);
}
