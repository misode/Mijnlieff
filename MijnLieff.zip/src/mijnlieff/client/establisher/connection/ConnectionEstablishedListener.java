package mijnlieff.client.establisher.connection;

import mijnlieff.client.Connection;

public interface ConnectionEstablishedListener {

    void establishedConnection(Connection connection);
}
